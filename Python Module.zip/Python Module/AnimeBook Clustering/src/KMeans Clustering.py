import pandas as pd                               # For data management

import matplotlib.pyplot as plt                   # For data visualization

from sklearn.cluster import KMeans                # To instantiate, train and use model
from sklearn import metrics                       # For Model Evaluation


# Load dataset
dataset = pd.read_csv("../Dataset/UserDBWekaReady.csv") #Dataset is a dataframe
dataset.pop("userid") # ignores userid attribute from dataset
dataset.pop("profile") # ignores username attribute from dataset


#Silhouette test
n = range(2, 40)  # number of k values to test
silhouette_scores = [] #array that will store all shlhouette scores for each k

for k in n: #run kmeans for each k value that must be tested
    kmeansClusterer = KMeans(n_clusters=k)
    kmeansClusterer.fit(dataset)
    labels_k = kmeansClusterer.labels_
    score_k = metrics.silhouette_score(dataset, labels_k) #compute silhouette score for each k
    silhouette_scores.append(score_k)    # add silhouette score for each successful computation
    print("Tested kMeans with k = %d\tSS: %5.4f" % (k, score_k))

print("Done!")

#Show silhouette graph

plt.figure(figsize=(16,8))
plt.plot(n, silhouette_scores, 'bx-')
plt.xlabel('k')
plt.ylabel('Score')
plt.title('The Silhouette Score showing the optimal k')
plt.show()

#Show Elbow Method

variances = [] # all variances list
n = range(2,40) # number of k values to test

for k in n:
    kmeansClusterer = KMeans(n_clusters=k)
    kmeansClusterer.fit(dataset)
    variances.append(kmeansClusterer.inertia_) #compute the sum of squared distances of samples to their closest cluster center
    print("Tested kMeans with k = %d\tVariances: %.5f" % (k, kmeansClusterer.inertia_))

#Show Elbow Method graph
plt.figure(figsize=(16,8))
plt.plot(n, variances, 'bx-')

plt.xlabel('k')
plt.ylabel('Cost Functions')
plt.title('The Elbow Method showing the optimal k')
plt.show()
