import numpy as np                                   # For data management
import pandas as pd                                  # For data management
import scipy.cluster.hierarchy as shc                # For dendogram creation

import seaborn as sns                                # For data visualization and specifically for pairplot()
import matplotlib.pyplot as plt                      # For data visualization
from sklearn import metrics                          # For Computing Silhouette Score

from sklearn.cluster import AgglomerativeClustering  # To cluster data


# Load dataset
dataset = pd.read_csv("../Dataset/UserDBWekaReady.csv") #Dataset is a dataframe
dataset.pop("userid") # ignores userid attribute from dataset
dataset.pop("profile") # ignores username attribute from dataset


#Dendogram builder

plt.figure(figsize=(50, 50))
plt.title("Dataset Dendograms")
dend = shc.dendrogram(shc.linkage(dataset, method='ward'))
plt.show()


#Silhouette test to find best k
n = range(2, 40)  # number of k values to test
silhouette_scores = [] #array that will store all shlhouette scores for each k

for k in n: #run kmeans for each k value that must be tested
    clusterer = AgglomerativeClustering(n_clusters=k, affinity='euclidean', linkage='ward')
    clusterer.fit(dataset)
    labels_k = clusterer.labels_
    score_k = metrics.silhouette_score(dataset, labels_k) # compute silhouette score for each k
    silhouette_scores.append(score_k)    # add silhouette score for each successful computation
    print("Tested kMeans with k = %d\tSS: %5.4f" % (k, score_k))

print("Done!")

#Show silhouette graph

plt.figure(figsize=(16,8))
plt.plot(n, silhouette_scores, 'bx-')
plt.xlabel('k')
plt.ylabel('Score')
plt.title('The Silhouette Score showing the optimal k')
plt.show()

#Run clustering to check Cluster Distribution

num_cluster = 20
k_value = str(num_cluster)
cluster = AgglomerativeClustering(n_clusters=20, affinity='euclidean', linkage='ward')
result = cluster.fit_predict(dataset)

#Print cluster assignment on console
print(result, type(result))
cluster_occurrencies = np.zeros(num_cluster)

#Count how many clusters belong to a cluster
for elem in result:
    cluster_occurrencies[elem] += 1

print(cluster_occurrencies)
